import { Link } from 'react-router-dom'
import styles from './Header.module.css'

function Header() {
    return (
        <header className={styles.header}>
            <nav>
                <Link to="/">Times</Link>
                <Link to="/sobre">Mascotes</Link>
                <Link to="/projetos">Estádios</Link>
                <Link to="/contatos">Estados</Link>
            </nav>
        </header>
    )    
}

export default Header