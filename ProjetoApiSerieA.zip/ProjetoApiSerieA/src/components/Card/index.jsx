import styles from './Card.module.css'

// eslint-disable-next-line react/prop-types
function Card({ nome, mascote, estadio, estado, img}) {
    return (
        <section className={styles.card}>
            <img src={img} className={styles.img}/>
            <h3>{nome}</h3>
            <p>{mascote}</p>
            <p>{estadio}</p>
            <p>{estado}</p>
        </section>
    )
}

export default Card